import os,pathlib,socket,subprocess,time,uuid,json
root=pathlib.Path('/private/tmp/ade-phase16-phase13-regression-2');root.mkdir(exist_ok=False)
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
with socket.socket() as s:s.bind(('127.0.0.1',0));console=s.getsockname()[1]
endpoint=f'http://127.0.0.1:{port}'
env=dict(os.environ,AWS_ACCESS_KEY_ID='ade-fixture',AWS_SECRET_ACCESS_KEY='ade-fixture-secret',ADE_REMOTE_ENDPOINT=endpoint,OPENSSL_DIR='/opt/homebrew/opt/openssl@3',OPENSSL_ROOT_DIR='/opt/homebrew/opt/openssl@3')
env.update(MINIO_ROOT_USER=env['AWS_ACCESS_KEY_ID'],MINIO_ROOT_PASSWORD=env['AWS_SECRET_ACCESS_KEY'],MINIO_BROWSER='off')
log=open(root/'minio.log','wb');p=subprocess.Popen(['/private/tmp/ade-phase16-tools/minio','server','--address',f'127.0.0.1:{port}','--console-address',f'127.0.0.1:{console}',str(root/'data')],env=env,stdout=log,stderr=subprocess.STDOUT)
commands=[]
try:
 for i in range(150):
  if p.poll() is not None:raise ValueError('server exited')
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.1):break
  except OSError:time.sleep(.1)
 code="import boto3,os,sys; from botocore.config import Config; s=boto3.client('s3',endpoint_url=sys.argv[1],region_name='us-east-1',aws_access_key_id=os.environ['AWS_ACCESS_KEY_ID'],aws_secret_access_key=os.environ['AWS_SECRET_ACCESS_KEY'],config=Config(proxies={},retries={'max_attempts':0}));s.create_bucket(Bucket='ade-phase13-test')"
 subprocess.run(['/private/tmp/ade-phase13-g0/service-venv/bin/python','-c',code,endpoint],env=env,check=True)
 for name in ['genuine_remote_static_turnover_and_scoped_cleanup','real_remote_corruption_missing_old_partial_sources_and_reader_death_never_return_output','immutable_cleanup_capability_cannot_delete_another_live_namespace']:
  cmd=['cargo','test','-p','ade-distributed','--all-features','--locked','--offline','--test','remote',name,'--','--ignored','--nocapture','--test-threads=1'];commands.append(cmd)
  with open(root/(name+'.log'),'wb') as out:r=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
  if r.returncode:raise ValueError(name+' failed')
 (root/'commands.json').write_text(json.dumps(commands,indent=2));(root/'result.json').write_text(json.dumps(dict(tests=3,status='PASS',endpoint=endpoint)))
finally:
 p.terminate();p.wait(10);log.close()
