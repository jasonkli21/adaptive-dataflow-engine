//! Internal attempt commit boundary, isolated from external sink transactions.
use crate::{
    Result,
    bounded_output::{OutputBudget, OutputLimits},
    exchange::{self, Receiver, Store},
    ids::{AttemptId, JobId, transfer},
    metrics::NetworkMetrics,
    require,
};
use std::{
    collections::BTreeMap,
    net::{SocketAddr, TcpListener},
    path::Path,
    sync::Arc,
};

pub(crate) struct Gather {
    stores: BTreeMap<(u64, u64), Arc<Store>>,
    receivers: Vec<Receiver>,
    committed: BTreeMap<u64, AttemptId>,
    job: JobId,
    workers: usize,
    active: std::collections::BTreeSet<u64>,
}
impl Gather {
    #[cfg(test)]
    pub(crate) fn new(parent: &Path, job: JobId, workers: usize) -> Result<Self> {
        Self::with_active(parent, job, workers, (0..workers as u64).collect())
    }
    #[cfg(test)]
    pub(crate) fn with_active(
        parent: &Path,
        job: JobId,
        workers: usize,
        active: std::collections::BTreeSet<u64>,
    ) -> Result<Self> {
        Self::with_context(parent, job, workers, active, None)
    }
    pub(crate) fn with_context(
        parent: &Path,
        job: JobId,
        workers: usize,
        active: std::collections::BTreeSet<u64>,
        schedule: Option<(&str, &crate::scheduler::Config)>,
    ) -> Result<Self> {
        Self::with_budget(parent, job, workers, active, schedule, None)
    }
    pub(crate) fn with_budget(
        parent: &Path,
        job: JobId,
        workers: usize,
        active: std::collections::BTreeSet<u64>,
        schedule: Option<(&str, &crate::scheduler::Config)>,
        disk: Option<&Arc<crate::disk::Budget>>,
    ) -> Result<Self> {
        require(
            !active.is_empty() && active.iter().all(|p| *p < workers as u64),
            "invalid gather active set",
        )?;
        let mut stores = BTreeMap::new();
        for p in active.iter().copied() {
            stores.insert(
                (p, 0),
                Arc::new(if let Some((digest, c)) = schedule {
                    Store::typed(
                        parent,
                        [transfer(job, 1, 0, workers as u64 + p)].into(),
                        ade_exec::CancellationToken::default(),
                        crate::ExchangeConfig::default(),
                        exchange::Payload::LeasedAggregate,
                        digest.into(),
                        exchange::IngressLimits {
                            rows: c.max_input_rows,
                            bytes: c.max_exchange_bytes,
                            batches: c.max_exchange_frames,
                        },
                        None,
                    )?
                } else {
                    Store::configured_budget(
                        parent,
                        [transfer(job, 1, 0, workers as u64 + p)].into(),
                        ade_exec::CancellationToken::default(),
                        crate::ExchangeConfig::default(),
                        None,
                        disk.cloned(),
                    )?
                }),
            );
        }
        let routing = stores.clone();
        let receiver = Receiver::start(TcpListener::bind("127.0.0.1:0")?, move |header| {
            let p = header
                .id
                .producer
                .0
                .checked_sub(workers as u64)
                .ok_or_else(|| crate::Error::Invalid("invalid gather producer".into()))?;
            routing
                .get(&(p, header.id.attempt.0))
                .cloned()
                .ok_or_else(|| crate::Error::Invalid("unexpected gather attempt".into()))
        })?;
        Ok(Self {
            stores,
            receivers: vec![receiver],
            committed: BTreeMap::new(),
            job,
            workers,
            active,
        })
    }
    pub(crate) fn address(&self) -> SocketAddr {
        self.receivers[0].address
    }
    pub(crate) fn start_recovery(&mut self, parent: &Path, partition: u64) -> Result<SocketAddr> {
        require(
            !self.committed.contains_key(&partition) && self.receivers.len() == 1,
            "duplicate/ambiguous gather recovery",
        )?;
        let old = &self.stores[&(partition, 0)];
        // Cancel before checking the terminal registry: an in-flight terminal cannot
        // be promoted after abandonment. A validated old terminal is ambiguous and fails.
        old.cancellation.cancel();
        require(
            old.metrics()?.transfers == 0,
            "ambiguous gather commit state",
        )?;
        let store =
            Arc::new(Store::new(
                parent,
                [transfer(self.job, 1, 0, self.workers as u64 + partition)
                    .with_attempt(AttemptId(1))]
                .into(),
                ade_exec::CancellationToken::default(),
            )?);
        let receiving = store.clone();
        let receiver = Receiver::start(TcpListener::bind("127.0.0.1:0")?, move |_| {
            Ok(receiving.clone())
        })?;
        let address = receiver.address;
        self.stores.insert((partition, 1), store);
        self.receivers.push(receiver);
        Ok(address)
    }
    #[cfg(feature = "research-hooks")]
    pub(crate) fn wait_for_partial_prefix(
        &self,
        partition: u64,
        timeout: std::time::Duration,
    ) -> Result<()> {
        let id = transfer(self.job, 1, 0, self.workers as u64 + partition);
        let store = &self.stores[&(partition, 0)];
        let deadline = std::time::Instant::now() + timeout;
        loop {
            let batches = store.observed_batches(id)?;
            if batches > 0 {
                require(
                    batches == 1,
                    "research failure did not leave a one-batch prefix",
                )?;
                return Ok(());
            }
            require(
                std::time::Instant::now() < deadline,
                "research failure produced no accepted gather batch",
            )?;
            std::thread::sleep(std::time::Duration::from_millis(2));
        }
    }
    pub(crate) fn commit(
        &mut self,
        partition: u64,
        attempt: AttemptId,
        sent: &NetworkMetrics,
    ) -> Result<()> {
        require(
            !self.committed.contains_key(&partition),
            "duplicate gather success",
        )?;
        let store = self
            .stores
            .get(&(partition, attempt.0))
            .ok_or_else(|| crate::Error::Invalid("unexpected gather attempt".into()))?;
        let accepted = store.metrics()?;
        require(
            accepted.transfers == 1
                && accepted.transfers == sent.transfers
                && accepted.batches == sent.batches
                && accepted.rows == sent.rows
                && accepted.payload_bytes == sent.payload_bytes,
            "gather terminal conservation failure",
        )?;
        self.committed.insert(partition, attempt);
        Ok(())
    }
    pub(crate) fn verify_terminal(
        &self,
        partition: u64,
        expected: &crate::lineage::TransferManifest,
    ) -> Result<()> {
        let id = transfer(self.job, 1, 0, self.workers as u64 + partition);
        require(
            expected.logical == id.logical()
                && expected.attempt == id.attempt
                && expected.fingerprint == self.stores[&(partition, 0)].terminal(id)?,
            "managed final fingerprint mismatch",
        )
    }
    pub(crate) fn attempts(&self) -> BTreeMap<u64, AttemptId> {
        self.committed.clone()
    }
    pub(crate) fn stream(
        &self,
        mut sink: impl FnMut(u64, arrow::record_batch::RecordBatch) -> Result<()>,
    ) -> Result<Vec<crate::managed::Terminal>> {
        require(
            self.committed.len() == self.workers,
            "managed complete final set",
        )?;
        let mut terminals = vec![];
        for (partition, attempt) in &self.committed {
            require(attempt.0 == 0, "managed engine replay forbidden")?;
            let store = &self.stores[&(*partition, 0)];
            let metrics = store.metrics()?;
            let fingerprint =
                store.terminal(transfer(self.job, 1, 0, self.workers as u64 + partition))?;
            exchange::visit_batches(store, |batch| sink(*partition, batch))?;
            terminals.push(crate::managed::Terminal {
                partition: *partition,
                rows: metrics.rows,
                batches: metrics.batches,
                bytes: metrics.payload_bytes,
                fingerprint,
            });
        }
        Ok(terminals)
    }
    pub(crate) fn collect(
        &self,
    ) -> Result<(Vec<arrow::record_batch::RecordBatch>, NetworkMetrics)> {
        self.collect_inner(None, Ok)
    }

    pub(crate) fn collect_bounded(
        &self,
        limits: OutputLimits,
        adapt: impl FnMut(arrow::record_batch::RecordBatch) -> Result<arrow::record_batch::RecordBatch>,
    ) -> Result<(Vec<arrow::record_batch::RecordBatch>, NetworkMetrics)> {
        let budget = OutputBudget::new(limits)?;
        self.collect_inner(Some(budget), adapt)
    }

    fn collect_inner(
        &self,
        mut budget: Option<OutputBudget>,
        mut adapt: impl FnMut(
            arrow::record_batch::RecordBatch,
        ) -> Result<arrow::record_batch::RecordBatch>,
    ) -> Result<(Vec<arrow::record_batch::RecordBatch>, NetworkMetrics)> {
        require(
            self.committed
                .keys()
                .copied()
                .collect::<std::collections::BTreeSet<_>>()
                == self.active,
            "incomplete gather partition set",
        )?;
        let mut batches = Vec::new();
        let mut metrics = NetworkMetrics::default();
        for (p, attempt) in &self.committed {
            let store = &self.stores[&(*p, attempt.0)];
            exchange::visit_batches(store, |batch| {
                let batch = adapt(batch)?;
                if let Some(budget) = budget.as_mut() {
                    budget.include(&batch)?;
                }
                batches.push(batch);
                Ok(())
            })?;
            metrics.add(&store.metrics()?);
        }
        Ok((batches, metrics))
    }
}
impl Drop for Gather {
    fn drop(&mut self) {
        for store in self.stores.values() {
            store.cancellation.cancel();
        }
        self.receivers.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::exchange::{Header, Sender};
    use std::io::Write;
    #[test]
    fn incomplete_original_is_quarantined_and_only_one_attempt_commits() {
        let root = tempfile::tempdir().unwrap();
        let mut gather = Gather::new(root.path(), JobId(7), 2).unwrap();
        let id = transfer(JobId(7), 1, 0, 2);
        let mut incomplete = crate::protocol::connect(gather.address(), crate::IO_TIMEOUT).unwrap();
        crate::protocol::write_message(&mut incomplete, &Header::new(id)).unwrap();
        // Header accepted, but no terminal. Abandon while its connection is open.
        let recovery_address = gather.start_recovery(root.path(), 0).unwrap();
        let sent = Sender::new(
            recovery_address,
            id.with_attempt(AttemptId(1)),
            ade_exec::CancellationToken::default(),
        )
        .unwrap()
        .finish()
        .unwrap();
        gather.commit(0, AttemptId(1), &sent).unwrap();
        assert!(gather.commit(0, AttemptId(1), &sent).is_err());
        let _ = incomplete.write_all(&[0; 12]);
        drop(incomplete);
        assert!(
            Sender::new(gather.address(), id, ade_exec::CancellationToken::default())
                .unwrap()
                .finish()
                .is_err()
        );
        let normal = Sender::new(
            gather.address(),
            transfer(JobId(7), 1, 0, 3),
            ade_exec::CancellationToken::default(),
        )
        .unwrap()
        .finish()
        .unwrap();
        gather.commit(1, AttemptId(0), &normal).unwrap();
        let (batches, metrics) = gather.collect().unwrap();
        assert_eq!(batches.len(), 0);
        assert_eq!(metrics.transfers, 2);
        assert_eq!(
            gather.attempts(),
            [(0, AttemptId(1)), (1, AttemptId(0))].into()
        );
    }
    #[test]
    fn completed_original_cannot_be_replaced_and_incomplete_output_cannot_commit() {
        let root = tempfile::tempdir().unwrap();
        let mut gather = Gather::new(root.path(), JobId(8), 2).unwrap();
        assert!(
            gather
                .commit(0, AttemptId(0), &NetworkMetrics::default())
                .is_err()
        );
        assert!(gather.collect().is_err());
        let sent = Sender::new(
            gather.address(),
            transfer(JobId(8), 1, 0, 2),
            ade_exec::CancellationToken::default(),
        )
        .unwrap()
        .finish()
        .unwrap();
        assert!(gather.start_recovery(root.path(), 0).is_err());
        // A separate normal partition commits exactly once.
        let other = Sender::new(
            gather.address(),
            transfer(JobId(8), 1, 0, 3),
            ade_exec::CancellationToken::default(),
        )
        .unwrap()
        .finish()
        .unwrap();
        gather.commit(1, AttemptId(0), &other).unwrap();
        assert!(gather.commit(1, AttemptId(1), &sent).is_err());
    }
}
