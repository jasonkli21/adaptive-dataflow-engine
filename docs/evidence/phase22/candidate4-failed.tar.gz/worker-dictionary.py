import os, sys
import pyarrow as pa
import pyarrow.compute as pc

def transform(batch):
    return batch.set_column(6, 'payload', pc.dictionary_encode(batch.column(6)))
