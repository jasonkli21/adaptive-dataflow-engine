import os, sys
import pyarrow as pa
import pyarrow.compute as pc

def transform(batch):
    os._exit(27)
