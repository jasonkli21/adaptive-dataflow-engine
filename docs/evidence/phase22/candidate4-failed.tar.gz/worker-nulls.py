import os, sys
import pyarrow as pa
import pyarrow.compute as pc

def transform(batch):
    return batch.set_column(2, batch.schema.field(2), pa.nulls(batch.num_rows, type=pa.uint64()))
