import os, sys
import pyarrow as pa
import pyarrow.compute as pc

def transform(batch):
    sys.stdout.buffer.write(b'X' * (1024 * 1024 + 1)); return batch
