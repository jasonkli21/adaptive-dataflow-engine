import os, sys
import pyarrow as pa
import pyarrow.compute as pc

def transform(batch):
    sys.stderr.write('PHASE22_REDACTION_SENTINEL'); sys.stderr.flush(); return batch
