import os, sys
import pyarrow as pa
import pyarrow.compute as pc

def transform(batch):
    return batch.take(list(reversed(range(batch.num_rows))))
