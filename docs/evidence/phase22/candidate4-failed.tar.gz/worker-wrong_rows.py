import os, sys
import pyarrow as pa
import pyarrow.compute as pc

def transform(batch):
    return batch if batch.column(0)[0].as_py() == 2**63 else batch.slice(1)
