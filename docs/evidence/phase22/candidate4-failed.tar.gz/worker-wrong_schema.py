import os, sys
import pyarrow as pa
import pyarrow.compute as pc

def transform(batch):
    return batch.rename_columns(['changed', *batch.schema.names[1:]])
