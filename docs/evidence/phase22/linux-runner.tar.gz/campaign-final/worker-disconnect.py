
import os
import time
from pathlib import Path

def transform(batch):
    Path('/evidence/campaign-final/worker-disconnect.pid').write_text(str(os.getpid()))
    time.sleep(60)
    return batch
