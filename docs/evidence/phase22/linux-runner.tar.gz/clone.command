git clone --shared --local /source /work/ade 
