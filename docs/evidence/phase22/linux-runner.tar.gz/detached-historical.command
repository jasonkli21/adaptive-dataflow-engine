/work/venv/bin/python scripts/phase22/verify.py --mode historical-archive --receipt-pin 53e39d2ab7e3082eabb7f1ec76b819969ded982b580816313f5fbeed4e62fd74 /work/detached-phase22 
