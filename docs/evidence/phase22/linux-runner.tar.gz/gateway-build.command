cargo build --locked -p ade-gateway --features flight-sql-v1 --bin ade-gateway --example phase22-native 
