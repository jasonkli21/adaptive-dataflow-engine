/maven/bin/mvn -B -f clients/java/pom.xml compile dependency:build-classpath -Dmdep.outputFile=target/classpath.txt 
