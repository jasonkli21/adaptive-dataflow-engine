cargo check -p ade-gateway -p ade-exec --no-default-features --all-targets --locked 
