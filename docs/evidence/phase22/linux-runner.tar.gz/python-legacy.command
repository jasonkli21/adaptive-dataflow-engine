python3 -m unittest discover -s scripts/tests -p test_\*.py 
