#!/usr/bin/env bash
set -eu
step() {
    local label=$1
    shift
    printf '%q ' "$@" > "/evidence/$label.command"
    printf '\n' >> "/evidence/$label.command"
    local status=0
    "$@" > "/evidence/$label.log" 2>&1 || status=$?
    echo "$status" > "/evidence/$label.exit"
    printf '%s %s\n' "$label" "$status"
    return "$status"
}
export DEBIAN_FRONTEND=noninteractive
export CARGO_BUILD_JOBS=5
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_PROFILE_TEST_DEBUG=0
export PYTHONDONTWRITEBYTECODE=1
step setup-apt-update apt-get update
step setup-apt-install apt-get install -y --no-install-recommends cmake libcurl4-openssl-dev libsasl2-dev pkg-config python3 python3-venv openjdk-17-jdk-headless procps
step setup-rust rustup component add rustfmt clippy
step setup-git-safe git config --global --add safe.directory /source
step clone git clone --shared --local /source /work/ade
cd /work/ade
git -C /source ls-files -z --cached --others --exclude-standard -- Cargo.toml Cargo.lock rust-toolchain.toml rustfmt.toml crates clients scripts benchmarks .github/workflows/ci.yml | tar -C /source --null -T - -cf - | tar -xf -
step platform uname -a
step system-release cat /etc/os-release
step toolchain rustc -Vv
step format cargo fmt --all --check
step python-venv python3 -m venv /work/venv
step python-package /work/venv/bin/python -m pip install ./clients/python blake3==1.0.8
step java-build /maven/bin/mvn -B -f clients/java/pom.xml compile dependency:build-classpath -Dmdep.outputFile=target/classpath.txt
# Standalone client/gateway job and then the legacy workspace job run in the same Linux image.
step gateway-build cargo build --locked -p ade-gateway --features flight-sql-v1 --bin ade-gateway --example phase22-native
step interop /work/venv/bin/python scripts/phase22/campaign.py --binary target/debug/ade-gateway --native target/debug/examples/phase22-native --java /usr/bin/java --java-classpath "$(cat clients/java/target/classpath.txt)" --interop-only --output /evidence/interop
step verifier-unit /work/venv/bin/python -m unittest discover -s scripts/phase22 -p test_verify.py
step python-legacy python3 -m unittest discover -s scripts/tests -p 'test_*.py'
step check cargo check --workspace --all-targets --locked
step no-default cargo check -p ade-gateway -p ade-exec --no-default-features --all-targets --locked
step clippy cargo clippy --workspace --all-targets --all-features --locked -- -D warnings
step build cargo build --workspace --all-features --locked
step test cargo test --workspace --all-features --locked
step smoke bash scripts/smoke.sh
