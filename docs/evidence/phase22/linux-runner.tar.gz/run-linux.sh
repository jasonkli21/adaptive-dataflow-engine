#!/usr/bin/env bash
set -eu
step() {
    local label=$1
    shift
    printf '%q ' "$@" > "/evidence/$label.command"
    printf '\n' >> "/evidence/$label.command"
    local status=0
    "$@" > "/evidence/$label.log" 2>&1 || status=$?
    echo "$status" > "/evidence/$label.exit"
    printf '%s %s\n' "$label" "$status"
    return "$status"
}
cd /work/ade
export PYTHONDONTWRITEBYTECODE=1
step interop-final /work/venv/bin/python scripts/phase22/campaign.py --binary /work/final-bins/ade-gateway --native /work/final-bins/phase22-native --java /usr/bin/java --java-classpath "$(cat clients/java/target/classpath.txt)" --interop-only --output /evidence/interop-final
mkdir -p /work/detached-phase22
tar -xzf /source/docs/evidence/phase22/candidate-final.tar.gz -C /work/detached-phase22
phase22_pin="$(cat /source/docs/evidence/phase22/candidate-final.seal-sha256)"
step detached-historical /work/venv/bin/python scripts/phase22/verify.py --mode historical-archive --receipt-pin "$phase22_pin" /work/detached-phase22
step detached-tamper /work/venv/bin/python scripts/phase22/tamper.py --receipt-pin "$phase22_pin" /work/detached-phase22
