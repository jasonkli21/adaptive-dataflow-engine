apt-get install -y --no-install-recommends cmake libcurl4-openssl-dev libsasl2-dev pkg-config python3 python3-venv openjdk-17-jdk-headless procps 
