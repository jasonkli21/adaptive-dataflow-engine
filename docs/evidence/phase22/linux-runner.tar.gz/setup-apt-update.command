apt-get update 
