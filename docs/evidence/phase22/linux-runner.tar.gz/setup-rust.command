rustup component add rustfmt clippy 
