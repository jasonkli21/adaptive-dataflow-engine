cat /etc/os-release 
