
import pyarrow as pa

def transform(batch):
    options = pa.ipc.IpcWriteOptions
    pa.ipc.IpcWriteOptions = lambda **kw: options(compression="zstd")
    return batch
