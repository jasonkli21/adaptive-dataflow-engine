MODE = 'wrong_batch'

import struct
import sys
import pyarrow as pa


class MutatingStdout:
    def __init__(self):
        self.original = sys.stdout.buffer
        self.buffer = self
        self.header = None

    def flush(self):
        self.original.flush()

    def write(self, value):
        if self.header is None:
            self.header = bytearray(value)
            return len(value)
        payload = bytearray(value)
        if MODE == "wrong_batch":
            self.header[8] ^= 1
        elif MODE == "trailing":
            payload += b"trailing"
        elif MODE == "malformed":
            payload[0] = 0
        elif MODE == "oversized_decoded":
            schema_length = struct.unpack_from("<I", payload, 4)[0]
            metadata = 8 + schema_length + 8
            table = metadata + struct.unpack_from("<I", payload, metadata)[0]
            vtable = table - struct.unpack_from("<i", payload, table)[0]
            offset = struct.unpack_from("<H", payload, vtable + 10)[0]
            assert offset != 0
            struct.pack_into("<q", payload, table + offset, 1 << 40)
        struct.pack_into("<I", self.header, 84, len(payload))
        self.original.write(self.header)
        self.original.write(payload)
        return len(value)


def transform(batch):
    sys.stdout = MutatingStdout()
    return batch
