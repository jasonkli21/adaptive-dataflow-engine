
import os
import time
from pathlib import Path

def transform(batch):
    Path('/private/tmp/ade22-fault-supplement/worker-hang.pid').write_text(str(os.getpid()))
    time.sleep(60)
    return batch
