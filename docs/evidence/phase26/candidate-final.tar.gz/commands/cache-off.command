cargo check -p ade-cache --no-default-features --locked 
