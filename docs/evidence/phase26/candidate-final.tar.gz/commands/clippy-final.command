cargo clippy --workspace --all-targets --all-features --locked -- -D warnings 
