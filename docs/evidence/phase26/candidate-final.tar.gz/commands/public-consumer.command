cargo test --manifest-path examples/phase25-external-consumer/Cargo.toml --locked 
