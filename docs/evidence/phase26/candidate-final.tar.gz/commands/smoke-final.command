bash scripts/smoke.sh 
